public class HelloWorld{

     public static void main(String []args){
        System.out.println("Nama : Jean Baptista Jimmy Robert Openg");
        System.out.println("NIM : 172200434");
     }
}
